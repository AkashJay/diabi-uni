import React from 'react';
import ReactDOM from 'react-dom';
import MainContainer from "./container/mainContainer";

ReactDOM.render(
    <MainContainer/>
    ,
    document.getElementById('root')
);

