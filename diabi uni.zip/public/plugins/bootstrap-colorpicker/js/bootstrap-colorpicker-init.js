$(function() { $('#colorinput1').colorpicker({ color: "", format: "hex" }); }); 
$(function() { $('#colorinput2').colorpicker({ color: "#AA3399", format: "rgba"}); }); 
$(function() { $('#cp1').colorpicker(); });